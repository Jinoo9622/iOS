//
//  MainViewController.swift
//  SpotifyLoginSampleApp
//
//  Created by 박진우 on 2021/11/28.
//

import UIKit
import FirebaseAuth

class MainViewController: UIViewController {
    
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var resetPasswordButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 뒤로가기 제스처 불가능 (로그인 화면으로 이동하는것을 막기 위함)
        navigationController?.interactivePopGestureRecognizer?.isEnabled = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.navigationBar.isHidden = true
        
        let email = Auth.auth().currentUser?.email ?? "고객"
        
        welcomeLabel.text = """
            환영합니다.
            \(email)님
            """
        // 이메일 인증 사용자 여부, 아닐 경우 비밀번호 초기화 버튼 숨김처리
        let isEmailSignIn = Auth.auth().currentUser?.providerData[0].providerID == "password"
        self.resetPasswordButton.isHidden = !isEmailSignIn
    }
    
    @IBAction func logoutButtonTapped(_ sender: Any) {
        let firebaseAuth = Auth.auth()
        
        do {
            try firebaseAuth.signOut()
            // 로그인방식 선택화면으로 이동
            self.navigationController?.popToRootViewController(animated: true)
        } catch let signOutError as NSError {
            print("ERROR: signout")
            print("\(signOutError)")
        }
    }
    
    @IBAction func resetPasswordButtonTapped(_ sender: Any) {
        let email = Auth.auth().currentUser?.email ?? ""
        // 현재 사용자의 email로, 비밀번호 reset 이메일 전송
        Auth.auth().sendPasswordReset(withEmail: email, completion: nil)
    }
    
    @IBAction func profileUpdateButtonTapped(_ sender: Any) {
        let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
        // UITextField 등을 이용하여 사용자가 displayName을 update하도록 수정 가능 ㅇㅇ
        changeRequest?.displayName = "Jinu"
        changeRequest?.commitChanges { _ in
            let displayName = Auth.auth().currentUser?.displayName ?? Auth.auth().currentUser?.email ?? "고객"
            
            self.welcomeLabel.text = """
                환영합니다.
                \(displayName)님
                """
        }
    }
}
